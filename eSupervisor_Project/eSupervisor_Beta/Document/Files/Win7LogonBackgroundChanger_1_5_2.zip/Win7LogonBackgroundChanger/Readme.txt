Windows 7 Logon Background Changer 1.5.2
________________________________________


This application contains english and french translations for its user interface, but it will work on any Windows 7 language and edition.

==========

Change log :

1.5.2 (2012/04/13) :
-Fixes the thumbnail loading bug

1.5.1 (2012/01/31) :
-Minor bug fixes and improvements

1.5.0 :
-Improved user interface (new visual theme, full screen mode, ...)
-Added folder navigation
-Fixes a crash that could occur when the user selects a folder containing a corrupted picture
-Subfolder pictures are no longer displayed automatically
-Various bug fixes


==========

This application automatically checks online if an update is available. 
It only sends the version number and the number of times the app has been launched, for statistical purpose.
It does not send any personal data and does not download any update without your consent.

You must read and accept the license terms before using this application. You can read them from here:

http://www.julien-manici.com/windows_7_logon_background_changer/

You can also download the source code of this application from the URL above.

==========

To use this application, you can:


-Run it directly by opening Win7LogonBackgroundChanger.exe 
(right click on it, and run it as administrator if you don't want other users of this computer to be able to change the logon background later)

OR

-If you prefer to install it, run setup.exe. 
To open the app once it is installed, go to Control Panel, Appearance and Personalization, or use the shortcut in the start menu.
